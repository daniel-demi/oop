package OOP.Provided;

public class IllegalBindException extends Exception{
}
