package OOP.Provided;

public class NoSuitableProviderFoundException extends Exception {
}
