package OOP.Provided;

public class MultipleProvidersException extends Exception {
}
