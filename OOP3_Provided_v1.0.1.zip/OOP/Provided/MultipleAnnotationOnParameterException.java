package OOP.Provided;

public class MultipleAnnotationOnParameterException extends Exception {
}
