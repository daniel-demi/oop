package OOP.Provided;

public class MultipleInjectConstructorsException extends Exception {}
