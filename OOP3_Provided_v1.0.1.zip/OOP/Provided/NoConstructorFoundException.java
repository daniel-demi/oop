package OOP.Provided;

public class NoConstructorFoundException extends Exception {
}
