package OOP.Provided;

public class MultipleProvidersException {
}
